#!/usr/bin/env node
// Private, one-pass research capture. Never mutates Wheelwright or places orders.
import { readFileSync, writeFileSync, mkdirSync, existsSync, chmodSync, renameSync } from 'node:fs';
import { join } from 'node:path';
import { parseEnv } from 'node:util';
import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';

const DIR = new URL('.', import.meta.url).pathname;
const POPULATION = JSON.parse(readFileSync(join(DIR, 'declared-population.json'), 'utf8'));
const ROOTS = POPULATION.underlyings.map(x => x.occ_underlying_symbol);
if (ROOTS.length !== 6072 || POPULATION.denominators.ordinary_option_class_rows !== 6381) {
  throw Error('declared_population_denominator_changed');
}
const key = process.env.TRADIER_API_KEY?.trim() ||
  parseEnv(readFileSync('/Users/bollich/options-prototype/.env', 'utf8')).TRADIER_API_KEY?.trim();
if (!key) throw Error('production_credential_unavailable');

const args = process.argv.slice(2);
const full = args.length === 2 && args[0] === '--full' && /^\d+$/.test(args[1]);
const pilot = args.length === 2 && args[0] === '--pilot' && /^\d+$/.test(args[1]);
if (!full && !pilot) throw Error('usage: node crosswalk.mjs --pilot COUNT | --full MAX_REQUESTS_PER_MINUTE');
const maxPerMinute = full ? Number(args[1]) : 12;
if (maxPerMinute < 1 || maxPerMinute > 120) throw Error('request_rate_out_of_bounds');
const selected = pilot ? ['XSP', 'SPY', 'BRKB', 'TSLL', 'AAPL'].slice(0, Number(args[1])) : ROOTS;
if (selected.length === 0 || selected.some(x => !ROOTS.includes(x))) throw Error('invalid_selection');

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const sha = b => createHash('sha256').update(b).digest('hex');
const safeHeaders = h => Object.fromEntries(['content-type', 'date', 'x-request-id',
  'x-ratelimit-allowed', 'x-ratelimit-used', 'x-ratelimit-available', 'x-ratelimit-expiry']
  .map(k => [k, h.get(k)]).filter(([, v]) => v && v.length <= 200 && !v.includes(key)));

const resultDir = join(DIR, pilot ? 'pilot' : 'full');
mkdirSync(resultDir, { recursive: true, mode: 0o700 });
chmodSync(resultDir, 0o700);
const output = join(resultDir, 'manifest.json');
const manifest = existsSync(output) ? JSON.parse(readFileSync(output, 'utf8')) : {
  schema: 'ww-tradier-identity-crosswalk-capture/v0',
  declared_population_sha256: sha(readFileSync(join(DIR, 'declared-population.json'))),
  requested_count: selected.length, mode: pilot ? 'pilot' : 'full',
  max_requests_per_minute: maxPerMinute, started_at_utc: new Date().toISOString(),
  completed_at_utc: null, stopped_reason: null,
  results: Object.fromEntries(selected.map(symbol => [symbol, { state: 'NOT_ATTEMPTED' }]))
};
if (manifest.declared_population_sha256 !== sha(readFileSync(join(DIR, 'declared-population.json'))) ||
    manifest.requested_count !== selected.length || manifest.mode !== (pilot ? 'pilot' : 'full')) {
  throw Error('manifest_population_or_mode_mismatch');
}
function persist() {
  const tmp = output + '.tmp';
  writeFileSync(tmp, JSON.stringify(manifest, null, 2) + '\n', { mode: 0o600 });
  chmodSync(tmp, 0o600);
  // Same-directory atomic replacement for interruption-safe progress.
  renameSync(tmp, output);
}
manifest.stopped_reason = null;
manifest.completed_at_utc = null;
manifest.max_requests_per_minute = maxPerMinute;
persist();

let lastStart = 0;
for (const symbol of selected) {
  if (manifest.results[symbol]?.state !== 'NOT_ATTEMPTED') continue;
  const elapsed = Date.now() - lastStart;
  const gap = Math.ceil(60_000 / maxPerMinute);
  if (lastStart && elapsed < gap) await sleep(gap - elapsed);
  const started = new Date().toISOString();
  lastStart = Date.now();
  const url = 'https://api.tradier.com/v1/markets/options/lookup?underlying=' + encodeURIComponent(symbol);
  let response, bytes;
  try {
    response = await fetch(url, { method: 'GET', redirect: 'error',
      headers: { Authorization: 'Bearer ' + key, Accept: 'application/json' },
      signal: AbortSignal.timeout(25_000) });
    bytes = Buffer.from(await response.arrayBuffer());
  } catch (e) {
    manifest.results[symbol] = { state: 'ACQUISITION_FAILURE', requested_underlying: symbol,
      started_at_utc: started, failed_at_utc: new Date().toISOString(), error: e?.name || 'network_error' };
    persist();
    continue;
  }
  const received = new Date().toISOString();
  if (bytes.length > 25_000_000 || bytes.includes(Buffer.from(key))) {
    manifest.results[symbol] = { state: 'EVIDENCE_FAILURE', requested_underlying: symbol,
      started_at_utc: started, received_at_utc: received, http_status: response.status,
      reason: bytes.length > 25_000_000 ? 'body_over_cap' : 'credential_echoed' };
    manifest.stopped_reason = 'unsafe_response'; persist(); break;
  }
  const bodyName = symbol.replace(/[^A-Za-z0-9._-]/g, '_') + '-' + sha(Buffer.from(symbol)).slice(0, 12) + '.json.gz';
  writeFileSync(join(resultDir, bodyName), gzipSync(bytes), { mode: 0o600 });
  let roots = [], count = null, state = 'EVIDENCE_FAILURE', reason = null;
  if (response.ok) {
    try {
      const json = JSON.parse(bytes.toString('utf8'));
      const groups = json?.symbols === null ? [] : json?.symbols;
      if (!Array.isArray(groups) || !groups.every(x => x && typeof x === 'object' &&
          typeof x.rootSymbol === 'string' && Array.isArray(x.options) &&
          x.options.every(y => typeof y === 'string'))) {
        reason = 'lookup_schema_unrecognized';
      } else {
        roots = [...new Set(groups.map(x => x.rootSymbol))].sort();
        count = groups.reduce((n, x) => n + x.options.length, 0);
        state = count ? 'OPTION_CLASSES_OBSERVED' : 'NO_OPTION_CLASSES_RETURNED';
      }
    } catch { reason = 'invalid_json'; }
  } else { state = 'HTTP_ERROR'; reason = 'http_' + response.status; }
  const headers = safeHeaders(response.headers);
  manifest.results[symbol] = { state, reason, requested_underlying: symbol,
    started_at_utc: started, received_at_utc: received, http_status: response.status,
    safe_response_headers: headers, raw_gzip: bodyName, raw_sha256: sha(bytes),
    raw_bytes: bytes.length, option_contract_count: count, provider_roots: roots };
  if ([401, 403, 429].includes(response.status) ||
      (Number(headers['x-ratelimit-available']) < 5 && headers['x-ratelimit-available'] != null)) {
    manifest.stopped_reason = 'provider_authority_or_rate_limit'; persist(); break;
  }
  persist();
  if (Object.values(manifest.results).filter(x => x.state !== 'NOT_ATTEMPTED').length % 100 === 0) {
    process.stderr.write(`captured ${Object.values(manifest.results).filter(x => x.state !== 'NOT_ATTEMPTED').length}/${selected.length}\n`);
  }
}
if (!manifest.stopped_reason && selected.every(s => manifest.results[s]?.state !== 'NOT_ATTEMPTED')) {
  manifest.completed_at_utc = new Date().toISOString();
}
persist();
process.stderr.write(`manifest: ${output}; completed: ${Boolean(manifest.completed_at_utc)}; stop: ${manifest.stopped_reason || 'none'}\n`);
