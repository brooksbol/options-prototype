#!/usr/bin/env python3
"""Lossless OCC-to-Tradier identity accounting for the private capture."""
import collections
import gzip
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
population_bytes = (HERE / 'declared-population.json').read_bytes()
population = json.loads(population_bytes)
manifest_path = HERE / 'full' / 'manifest.json'
manifest = json.loads(manifest_path.read_text())
alias_manifest = json.loads((HERE / 'aliases' / 'manifest.json').read_text())
empty_lookup_manifest = json.loads((HERE / 'empty-lookup' / 'manifest.json').read_text())
explicit_aliases = {'BRKB': 'BRK/B', 'BFB': 'BF/B'}
assert manifest['declared_population_sha256'] == hashlib.sha256(population_bytes).hexdigest()
assert population['denominators'] == {'underlyings': 6072, 'ordinary_option_class_rows': 6381}
assert len(manifest['results']) == 6072
assert empty_lookup_manifest['source_manifest_sha256'] == hashlib.sha256(manifest_path.read_bytes()).hexdigest()
assert empty_lookup_manifest['completed_at_utc'] and len(empty_lookup_manifest['results']) == 47

out_dir = HERE / 'analysis'
out_dir.mkdir(exist_ok=True)
underlying_states = collections.Counter()
class_states = collections.Counter()
class_forms = collections.Counter()
cohort_states = collections.defaultdict(collections.Counter)
root_counts = collections.Counter()
query_rows = []
class_rows = []
contract_count = 0
raw_bytes = 0
verified_raw_bodies = 0

for product in population['underlyings']:
    symbol = product['occ_underlying_symbol']
    evidence = manifest['results'][symbol]
    state = evidence['state']
    roots = evidence.get('provider_roots') or []
    alias = explicit_aliases.get(symbol)
    alias_evidence = alias_manifest['results'].get(alias) if alias else None
    alias_roots = alias_evidence.get('provider_roots') if alias_evidence else []
    lookup_evidence = empty_lookup_manifest['results'].get(symbol)
    lookup_exact = lookup_evidence.get('exact_results') if lookup_evidence else []
    if lookup_evidence:
        lookup_body = gzip.decompress((HERE / 'empty-lookup' / lookup_evidence['raw_gzip']).read_bytes())
        assert hashlib.sha256(lookup_body).hexdigest() == lookup_evidence['raw_sha256']
        assert lookup_evidence['http_status'] == 200 and lookup_evidence['parse_error'] is None
    if alias_evidence and alias_evidence.get('raw_gzip'):
        alias_body = gzip.decompress((HERE / 'aliases' / alias_evidence['raw_gzip']).read_bytes())
        assert hashlib.sha256(alias_body).hexdigest() == alias_evidence['raw_sha256']
        assert alias_roots == sorted(g['rootSymbol'] for g in (json.loads(alias_body).get('symbols') or []))
    if 'raw_gzip' in evidence:
        body = gzip.decompress((HERE / 'full' / evidence['raw_gzip']).read_bytes())
        assert hashlib.sha256(body).hexdigest() == evidence['raw_sha256'], symbol
        verified_raw_bodies += 1
        raw_bytes += len(body)
        if state in ('OPTION_CLASSES_OBSERVED', 'NO_OPTION_CLASSES_RETURNED'):
            parsed = json.loads(body)
            groups = parsed.get('symbols') or []
            assert sorted({g['rootSymbol'] for g in groups}) == roots, symbol
            assert sum(len(g['options']) for g in groups) == evidence['option_contract_count'], symbol
    if state == 'OPTION_CLASSES_OBSERVED':
        underlying_state = 'PROVIDER_QUERY_RETURNED_OPTION_ROOTS'
        contract_count += evidence['option_contract_count']
    elif alias_roots:
        underlying_state = 'UNDERLYING_ALIAS_RESOLVED_EXPLICITLY'
        contract_count += alias_evidence['option_contract_count']
    elif state == 'NO_OPTION_CLASSES_RETURNED':
        underlying_state = ('EXACT_UNDERLYING_LOOKUP_NO_OPTION_ROOTS' if lookup_exact else
                            'QUERY_EMPTY_UNDERLYING_IDENTITY_UNRESOLVED')
    elif state == 'NOT_ATTEMPTED':
        underlying_state = 'NOT_ATTEMPTED'
    else:
        underlying_state = state
    underlying_states[underlying_state] += 1
    for root in roots:
        root_counts[root] += 1
    for root in alias_roots:
        root_counts[root] += 1
    cboe_records = product['cboe_underlying_records']
    query_rows.append({
        'occ_underlying_symbol': symbol,
        'occ_option_class_count': len(product['occ_classes']),
        'cboe_symbol_types': sorted({x['symbol_type'] for x in cboe_records}),
        'cboe_exact_symbol_present': bool(cboe_records),
        'provider_query_symbol': symbol,
        'explicit_alias_query_symbol': alias if alias_roots else None,
        'explicit_alias_provider_roots': alias_roots,
        'explicit_alias_raw_sha256': alias_evidence.get('raw_sha256') if alias_roots else None,
        'secondary_lookup_exact_results': lookup_exact,
        'secondary_lookup_raw_sha256': lookup_evidence.get('raw_sha256') if lookup_evidence else None,
        'provider_underlying_state': underlying_state,
        'provider_roots': roots,
        'provider_contract_count': evidence.get('option_contract_count'),
        'http_status': evidence.get('http_status'),
        'received_at_utc': evidence.get('received_at_utc'),
        'raw_sha256': evidence.get('raw_sha256'),
        'raw_gzip': evidence.get('raw_gzip'),
    })
    for item in product['occ_classes']:
        occ_class = item['option_class_symbol']
        assert item['underlying_symbol'] == symbol
        if occ_class == symbol:
            form = 'SAME_AS_UNDERLYING'
        elif occ_class.startswith(symbol) and occ_class[len(symbol):].isdigit():
            form = 'NUMERIC_SUFFIX'
        else:
            form = 'OTHER_DIFFERENCE'
        class_forms[form] += 1
        if state == 'OPTION_CLASSES_OBSERVED':
            if occ_class in roots:
                class_state = 'EXACT_CLASS_ROOT_OBSERVED'
            else:
                class_state = 'UNDERLYING_QUERY_WITH_OPTIONS_CLASS_UNRESOLVED'
        elif alias_roots:
            if occ_class in alias_roots:
                class_state = 'EXACT_CLASS_ROOT_VIA_EXPLICIT_ALIAS'
            else:
                class_state = 'EXPLICIT_ALIAS_UNDERLYING_FOUND_CLASS_UNRESOLVED'
        elif state == 'NO_OPTION_CLASSES_RETURNED' and lookup_exact:
            class_state = 'EXACT_UNDERLYING_LOOKUP_CLASS_UNRESOLVED'
        elif state == 'NO_OPTION_CLASSES_RETURNED':
            class_state = 'QUERY_EMPTY_CLASS_UNRESOLVED'
        elif state == 'NOT_ATTEMPTED':
            class_state = 'NOT_ATTEMPTED'
        else:
            class_state = state
        class_states[class_state] += 1
        cohort_states[item['product_type']][class_state] += 1
        cohort_states[form][class_state] += 1
        if not cboe_records:
            cohort_states['CBOE_EXACT_SYMBOL_ABSENT'][class_state] += 1
        class_rows.append({
            'occ_underlying_symbol': symbol,
            'occ_option_class_symbol': occ_class,
            'occ_product_type': item['product_type'],
            'occ_class_form': form,
            'cboe_exact_symbol_present': bool(cboe_records),
            'provider_query_symbol': symbol,
            'explicit_alias_query_symbol': alias if alias_roots else None,
            'explicit_alias_provider_roots': alias_roots,
            'explicit_alias_raw_sha256': alias_evidence.get('raw_sha256') if alias_roots else None,
            'secondary_lookup_exact_results': lookup_exact,
            'secondary_lookup_raw_sha256': lookup_evidence.get('raw_sha256') if lookup_evidence else None,
            'provider_roots': roots,
            'provider_class_state': class_state,
            'provider_root_exact_match': occ_class if occ_class in roots else None,
            'raw_sha256': evidence.get('raw_sha256'),
            'raw_gzip': evidence.get('raw_gzip'),
        })

assert len(query_rows) == 6072 and len(class_rows) == 6381
assert sum(underlying_states.values()) == 6072
assert sum(class_states.values()) == 6381

summary = {
    'schema': 'ww-tradier-identity-crosswalk-analysis/v0',
    'occ_report_date': population['occ_report_date'],
    'source_population_sha256': hashlib.sha256(population_bytes).hexdigest(),
    'capture_manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
    'capture_started_at_utc': manifest['started_at_utc'],
    'capture_completed_at_utc': manifest['completed_at_utc'],
    'capture_stopped_reason': manifest['stopped_reason'],
    'explicit_alias_probe_completed_at_utc': alias_manifest['completed_at_utc'],
    'secondary_lookup_completed_at_utc': empty_lookup_manifest['completed_at_utc'],
    'declared_denominators': population['denominators'],
    'verified_raw_bodies': verified_raw_bodies,
    'raw_uncompressed_bytes': raw_bytes,
    'observed_contract_strings': contract_count,
    'distinct_provider_roots': len(root_counts),
    'underlying_states': dict(sorted(underlying_states.items())),
    'class_states': dict(sorted(class_states.items())),
    'occ_class_forms': dict(sorted(class_forms.items())),
    'cohort_class_states': {k: dict(sorted(v.items())) for k, v in sorted(cohort_states.items())},
    'identity_scope': 'Exact OCC query spelling only. Empty responses do not establish provider absence. No implicit aliases, exclusions, or market quality filtering.',
}
for name, rows in [('underlyings.jsonl', query_rows), ('classes.jsonl', class_rows)]:
    with (out_dir / name).open('w') as f:
        for row in rows:
            f.write(json.dumps(row, separators=(',', ':')) + '\n')
(out_dir / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
