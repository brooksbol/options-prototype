#!/usr/bin/env node
// Narrow, explicit spelling probe for the two OCC/Cboe punctuation exceptions.
import { readFileSync, writeFileSync, mkdirSync, chmodSync } from 'node:fs';
import { join } from 'node:path';
import { parseEnv } from 'node:util';
import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';

const dir = new URL('.', import.meta.url).pathname;
const key = process.env.TRADIER_API_KEY?.trim() ||
  parseEnv(readFileSync('/Users/bollich/options-prototype/.env', 'utf8')).TRADIER_API_KEY?.trim();
if (!key) throw Error('credential_unavailable');
const symbols = ['BRK/B', 'BRK.B', 'BF/B', 'BF.B'];
const out = join(dir, 'aliases');
mkdirSync(out, { recursive: true, mode: 0o700 }); chmodSync(out, 0o700);
const sha = b => createHash('sha256').update(b).digest('hex');
const manifest = { schema: 'ww-tradier-identity-alias-probe/v0',
  reason: 'Explicit OCC BRKB/BFB versus Cboe BRK.B/BF.B and documented Tradier slash spelling',
  started_at_utc: new Date().toISOString(), results: {} };
for (const symbol of symbols) {
  const start = new Date().toISOString();
  try {
    const response = await fetch('https://api.tradier.com/v1/markets/options/lookup?underlying=' + encodeURIComponent(symbol),
      { headers: { Authorization: 'Bearer ' + key, Accept: 'application/json' },
        redirect: 'error', signal: AbortSignal.timeout(25000) });
    const body = Buffer.from(await response.arrayBuffer());
    if (body.length > 25_000_000 || body.includes(Buffer.from(key))) throw Error('unsafe_response');
    const filename = sha(Buffer.from(symbol)).slice(0, 12) + '.json.gz';
    writeFileSync(join(out, filename), gzipSync(body), { mode: 0o600 });
    let roots = null, contracts = null, parse_error = null;
    try {
      const json = JSON.parse(body);
      const groups = json.symbols === null ? [] : json.symbols;
      if (!Array.isArray(groups) || !groups.every(g => typeof g.rootSymbol === 'string' &&
        Array.isArray(g.options) && g.options.every(x => typeof x === 'string'))) throw Error('schema');
      roots = groups.map(g => g.rootSymbol).sort();
      contracts = groups.reduce((n,g) => n + g.options.length,0);
    } catch (e) { parse_error = e.message; }
    manifest.results[symbol] = { start, received_at_utc: new Date().toISOString(),
      http_status: response.status, rate_remaining: response.headers.get('x-ratelimit-available'),
      raw_gzip: filename, raw_sha256: sha(body), raw_bytes: body.length,
      provider_roots: roots, option_contract_count: contracts, parse_error };
  } catch (e) {
    manifest.results[symbol] = { start, state: 'ACQUISITION_FAILURE', error: e.name };
  }
  writeFileSync(join(out, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n', { mode: 0o600 });
  await new Promise(resolve => setTimeout(resolve, 5000));
}
manifest.completed_at_utc = new Date().toISOString();
writeFileSync(join(out, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n', { mode: 0o600 });
process.stdout.write(JSON.stringify(Object.fromEntries(Object.entries(manifest.results).map(([s,r]) =>
  [s, { http_status: r.http_status, provider_roots: r.provider_roots, option_contract_count: r.option_contract_count, parse_error: r.parse_error }]))));
