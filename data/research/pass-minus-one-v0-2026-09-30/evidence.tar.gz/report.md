# OCC to Tradier identity crosswalk: bounded Pass −1 experiment

Research capture completed 2026-10-01 19:18 UTC. This is identity and evidence work only. It does not filter products, assess market quality, or infer Exit Reliability.

## Declared population and evidence

- OCC report date: 2026-09-30. Ordinary `EU`/`IU` rows: **6,381 option-class rows** across **6,072 distinct underlyings**. The full declared population is retained in `declared-population.json` (SHA-256 `c8e4049b47b14100981c325d340edba470064e968f01ba0f3f2395714fd7eb3d`).
- Cboe's four-market 2026-10-01 files are retained as classification/reference evidence in `source/`. Its exact-symbol absence does not remove an OCC row.
- Tradier production `GET /v1/markets/options/lookup?underlying=` was called once for every exact OCC underlying spelling. All 6,072 requests returned HTTP 200, all raw bodies are hashed and gzip-retained in `full/`, and the capture completed without a stop reason or acquisition failure. The raw response uses `symbols[].rootSymbol` and contract string arrays; the parser records that observed schema rather than assuming the documentation example's shape.
- A four-query explicit punctuation probe retained both slash and dot variants for `BRKB` and `BFB` in `aliases/`. A 47-query exact symbol-search probe for empty option lookups is retained in `empty-lookup/`. Both are dated, hashed, and separate from the initial denominator pass.

## Accountable underlying states (6,072)

| State | Count |
| --- | ---: |
| Exact OCC query returned option roots | 6,025 |
| Explicit slash alias returned option roots (`BRK/B`, `BF/B`) | 2 |
| Exact underlying search hit, but no option roots from option lookup | 12 |
| Empty option lookup and no exact secondary search hit; identity unresolved | 33 |

The 12 exact search hits include five `SIX*` indexes. The 33 without an exact search hit are **unresolved**, not established as absent from Tradier. There is no evidence-supported `underlying not found` conclusion in this experiment.

## Accountable OCC class states (6,381)

| State | Count |
| --- | ---: |
| Exact OCC class root reported from exact underlying query | 6,278 |
| Exact OCC class root reported through explicit slash alias | 2 |
| Underlying returned options, but OCC class root absent | 52 |
| Exact underlying search hit, but option lookup returned no roots | 13 |
| Underlying identity unresolved after empty option and secondary lookups | 36 |

The class mismatch cohort includes numbered/nonstandard-looking classes and index variants. For example, OCC has `SPX`, `SPX9`, and `SPXW`; Tradier reported `SPX` and `SPXW`, leaving `SPX9` unresolved. `TSLL` and `TSLL1` both appeared under the `TSLL` query. The numeric suffix cohort contains 323 OCC class rows: 279 exact root observations, 37 class-root mismatches despite options returned, five with exact underlying search hits but no roots, and two with unresolved underlying identity. The suffix is a label for inspection, not an exclusion rule.

Across exact underlying queries, 233 returned multiple provider roots. Only two provider-root associations fell outside the OCC class set for that queried underlying: `HON1` under `HONA`, and `DD1` under `Q`. They remain unmerged anomalies with raw contract strings retained. There are 6,282 distinct reported provider roots when the two slash-alias roots are included.

The Cboe exact-symbol-absent OCC cohort contains 735 underlyings. Of those, 690 exact OCC spelling queries returned option roots, 45 were empty; two of the latter were resolved by the explicit slash alias probe. This cohort is not excluded.

## Replay files and limits

- `source/`: frozen OCC and Cboe files.
- `declared-population.json`: all 6,072 products, their 6,381 OCC class rows, and exact Cboe reference records.
- `full/manifest.json`, `full/*.json.gz`: per-query timestamps, status, headers, hashes, option-root groups, raw provider bodies.
- `aliases/` and `empty-lookup/`: separate follow-up evidence and manifests.
- `analysis/summary.json`, `analysis/underlyings.jsonl`, `analysis/classes.jsonl`: complete state accounting with pointers to raw evidence.

The option lookup proves which roots Tradier exposed at observation time. It does not prove permanence, current tradability, quote quality, or that an empty result means the provider has no underlying. No automatic alias normalization, exclusion rule, or downstream funnel selection was applied. The research scripts and artifacts remain private and uncommitted; the Wheelwright repository was not changed or reconciled.
