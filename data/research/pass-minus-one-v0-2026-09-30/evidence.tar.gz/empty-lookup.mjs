#!/usr/bin/env node
// Exact-symbol lookup evidence for OCC underlyings whose option lookup was empty.
import { readFileSync, writeFileSync, mkdirSync, chmodSync } from 'node:fs';
import { join } from 'node:path';
import { parseEnv } from 'node:util';
import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';
const dir = new URL('.', import.meta.url).pathname;
const key = process.env.TRADIER_API_KEY?.trim() ||
  parseEnv(readFileSync('/Users/bollich/options-prototype/.env', 'utf8')).TRADIER_API_KEY?.trim();
if (!key) throw Error('credential_unavailable');
const source = JSON.parse(readFileSync(join(dir, 'full', 'manifest.json'), 'utf8'));
if (!source.completed_at_utc || source.stopped_reason) throw Error('source_capture_incomplete');
const symbols = Object.entries(source.results).filter(([,r]) => r.state === 'NO_OPTION_CLASSES_RETURNED').map(([s]) => s);
if (symbols.length !== 47) throw Error('empty_query_denominator_changed');
const out = join(dir, 'empty-lookup'); mkdirSync(out,{recursive:true,mode:0o700}); chmodSync(out,0o700);
const sha = b => createHash('sha256').update(b).digest('hex');
const manifest = {schema:'ww-tradier-empty-underlying-lookup/v0', source_manifest_sha256:sha(readFileSync(join(dir,'full','manifest.json'))),
  requested_count:symbols.length, started_at_utc:new Date().toISOString(), completed_at_utc:null, results:{}};
for (const symbol of symbols) {
  const started_at_utc = new Date().toISOString();
  try {
    const response = await fetch('https://api.tradier.com/v1/markets/lookup?q='+encodeURIComponent(symbol),{
      headers:{Authorization:'Bearer '+key,Accept:'application/json'},redirect:'error',signal:AbortSignal.timeout(25000)});
    const body=Buffer.from(await response.arrayBuffer());
    if (body.length>1_000_000 || body.includes(Buffer.from(key))) throw Error('unsafe_response');
    const filename=sha(Buffer.from(symbol)).slice(0,12)+'.json.gz';
    writeFileSync(join(out,filename),gzipSync(body),{mode:0o600});
    let exact=[], total=null, parse_error=null;
    try {
      const json=JSON.parse(body); let rows=json?.securities?.security;
      if(rows===null || rows===undefined)rows=[]; if(!Array.isArray(rows))rows=[rows];
      if(!rows.every(x=>x&&typeof x.symbol==='string'))throw Error('schema');
      exact=rows.filter(x=>x.symbol===symbol).map(x=>({symbol:x.symbol,type:x.type||null,exchange:x.exchange||null}));
      total=rows.length;
    } catch(e){parse_error=e.message;}
    manifest.results[symbol]={started_at_utc,received_at_utc:new Date().toISOString(),http_status:response.status,
      rate_remaining:response.headers.get('x-ratelimit-available'),raw_gzip:filename,raw_sha256:sha(body),
      raw_bytes:body.length,returned_count:total,exact_results:exact,parse_error};
    if([401,403,429].includes(response.status)|| Number(response.headers.get('x-ratelimit-available'))<5){
      manifest.stopped_reason='provider_authority_or_rate_limit';break;
    }
  }catch(e){manifest.results[symbol]={started_at_utc,state:'ACQUISITION_FAILURE',error:e.name};}
  writeFileSync(join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n',{mode:0o600});
  await new Promise(resolve=>setTimeout(resolve,500));
}
if(Object.keys(manifest.results).length===symbols.length&&!manifest.stopped_reason)manifest.completed_at_utc=new Date().toISOString();
writeFileSync(join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n',{mode:0o600});
process.stdout.write(JSON.stringify({requested:symbols.length,completed:Object.keys(manifest.results).length,
  exact_found:Object.values(manifest.results).filter(x=>x.exact_results?.length).length,
  stopped:manifest.stopped_reason||null})+'\n');
