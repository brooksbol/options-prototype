import { readFileSync, writeFileSync, mkdirSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { parseEnv } from 'node:util';

const key = process.env.TRADIER_API_KEY || parseEnv(readFileSync('/Users/bollich/options-prototype/.env', 'utf8')).TRADIER_API_KEY;
if (!key) throw new Error('credential unavailable');
const symbols = ['SPY','QQQ','XSP','SPX','TSLL','BRK/B','DRAM','TLT'];
const expiration = '2026-11-20';
const base = 'https://api.tradier.com/v1';
const output = mkdtempSync(join(tmpdir(), 'ww-specimen-pilot-'));
const rows=[];
const sleep = ms => new Promise(r => setTimeout(r,ms));
for (const symbol of symbols) {
  const queries = [
    ['quote', '/markets/quotes?symbols='+encodeURIComponent(symbol)],
    ['history', '/markets/history?symbol='+encodeURIComponent(symbol)+'&interval=daily&start=2026-07-01&end=2026-10-01'],
    ['expirations', '/markets/options/expirations?symbol='+encodeURIComponent(symbol)+'&includeAllRoots=true'],
    ['chain', '/markets/options/chains?symbol='+encodeURIComponent(symbol)+'&expiration='+expiration+'&greeks=true'],
  ];
  const dir = join(output, symbol.replace('/','_')); mkdirSync(dir);
  for (const [kind,path] of queries) {
    const started = new Date().toISOString(); let status=null,body='',error=null;
    try {
      const response = await fetch(base+path,{headers:{Authorization:'Bearer '+key,Accept:'application/json'},redirect:'error',signal:AbortSignal.timeout(20000)});
      status=response.status; body=await response.text();
    } catch(e) { error=String(e); }
    const ended = new Date().toISOString();
    const filename = kind+'.body'; writeFileSync(join(dir,filename),body);
    const sha256=createHash('sha256').update(body).digest('hex');
    rows.push({symbol,kind,path,status,error,started,ended,bytes:Buffer.byteLength(body),sha256,raw_artifact:symbol.replace('/','_')+'/'+filename});
    await sleep(600);
  }
}
const manifest={experiment:'bounded-specimen-selection-preflight-2026-10-01',symbols,expiration,rows};
writeFileSync(join(output,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({output,requests:rows.length,http200:rows.filter(r=>r.status===200).length,failures:rows.filter(r=>r.status!==200).map(r=>({symbol:r.symbol,kind:r.kind,status:r.status,error:r.error})),bytes:rows.reduce((n,r)=>n+r.bytes,0)}));
