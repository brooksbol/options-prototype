import json, math, statistics, pathlib, hashlib
from datetime import date
root=pathlib.Path(__file__).parent
protocol=json.loads((root/'protocol.json').read_text())
manifest=json.loads((root/'manifest.json').read_text())
for row in manifest['rows']:
 b=(root/row['raw_artifact']).read_bytes()
 assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
assert hashlib.sha256((root/'protocol.json').read_bytes()).hexdigest()==manifest['protocol_sha256']
classes={'SPY':['SPY'],'QQQ':['QQQ'],'XSP':['XSP'],'SPX':['SPX','SPXW','SPX9'],'TSLL':['TSLL','TSLL1'],'BRK/B':['BRKB'],'DRAM':['DRAM'],'TLT':['TLT']}
asof=date.fromisoformat('2026-10-01')
results=[]; history_summary=[]
for underlying in protocol['underlyings']:
 d=root/underlying.replace('/','_')
 quote=json.loads((d/'quote.body').read_text())['quotes']['quote']
 if isinstance(quote,list):quote=quote[0]
 S=float(quote['last'])
 hist=json.loads((d/'history.body').read_text())['history']['day']
 if isinstance(hist,dict):hist=[hist]
 bars=sorted((x for x in hist if x.get('close') is not None and x['date']<='2026-10-01'),key=lambda x:x['date'])
 closes=[float(x['close']) for x in bars]
 returns=[math.log(closes[i]/closes[i-1]) for i in range(1,len(closes))]
 rvs={str(w):statistics.stdev(returns[-w:])*math.sqrt(252) if len(returns)>=w else None for w in (20,40,60)}
 history_summary.append({'underlying':underlying,'quote_symbol':quote.get('symbol'),'quote_last':S,'quote_trade_date':quote.get('trade_date'),'bars':len(bars),'last_bar_date':bars[-1]['date'],'last_close':closes[-1],'rv':rvs,'max_abs_log_return':max(map(abs,returns))})
 for expiry in protocol['expirations']:
  dte=(date.fromisoformat(expiry)-asof).days
  chain=json.loads((d/('chain-'+expiry+'.body')).read_text()).get('options')
  opts=[] if not chain else chain.get('option',[])
  if isinstance(opts,dict):opts=[opts]
  for cls in classes[underlying]:
   puts=sorted([o for o in opts if o.get('root_symbol')==cls and o.get('option_type')=='put'],key=lambda o:o['strike'])
   for family in ('price_relative','rv_normalized'):
    for window in ([None] if family=='price_relative' else [20,40,60]):
     row={'underlying':underlying,'class_root':cls,'expiry':expiry,'dte':dte,'puts':len(puts),'family':family,'window':window,'state':None,'nonstandard_terms':cls=='TSLL1'}
     if cls=='SPX9':
      row['state']='IDENTITY_UNRESOLVED';results.append(row);continue
     if not puts:
      row['state']='NO_EXACT_CLASS_PUTS_AT_EXPIRY';results.append(row);continue
     if family=='price_relative':
      targets=[math.log(.95),math.log(.90)]
      coords=lambda o: math.log(float(o['strike'])/S)
     else:
      rv=rvs[str(window)]
      if not rv or rv<=0:
       row['state']='REFERENCE_VOL_UNAVAILABLE';results.append(row);continue
      targets=[-.5,-1.0]
      coords=lambda o: math.log(float(o['strike'])/S)/(rv*math.sqrt(dte/365))
     tolerance=abs(targets[0]-targets[1])*.25
     legs=[min(puts,key=lambda o:(abs(coords(o)-t),float(o['strike']))) for t in targets]
     errors=[abs(coords(o)-t) for o,t in zip(legs,targets)]
     row.update({'targets':targets,'tolerance':tolerance,'strikes':[o['strike'] for o in legs],'symbols':[o['symbol'] for o in legs],
      'coordinates':[coords(o) for o in legs],'errors':errors,'deltas':[o.get('greeks',{}).get('delta') if o.get('greeks') else None for o in legs],
      'expiration_types':[o.get('expiration_type') for o in legs],
      'contract_sizes':[o.get('contract_size') for o in legs]})
     row['state']='MATCH' if all(e<=tolerance for e in errors) and legs[0]['strike']>legs[1]['strike'] else 'UNMATCHED_GRID'
     results.append(row)
out={'schema':'ww-specimen-rule-pilot-analysis/v0','protocol_sha256':manifest['protocol_sha256'],'raw_responses_verified':len(manifest['rows']),'history':history_summary,'results':results}
(root/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print('verified_responses',len(manifest['rows']),'rows',len(results))
for family in ['price_relative','rv_normalized']:
 for expiry in protocol['expirations']:
  for window in ([None] if family=='price_relative' else [20,40,60]):
   rows=[x for x in results if x['family']==family and x['expiry']==expiry and x['window']==window]
   matched=[x for x in rows if x['state']=='MATCH' and x['class_root'] not in ('TSLL1','SPX9')]
   ds=[x['deltas'][0] for x in matched if isinstance(x['deltas'][0],(int,float))]
   longds=[x['deltas'][1] for x in matched if isinstance(x['deltas'][1],(int,float))]
   print(family,expiry,window,'match',len(matched),'of',len(rows)-2,'states',{s:sum(x['state']==s for x in rows) for s in sorted(set(x['state'] for x in rows))},'short_range', (round(min(ds),4),round(max(ds),4)) if ds else None,'short_sd',round(statistics.stdev(ds),4) if len(ds)>1 else None,'long_range',(round(min(longds),4),round(max(longds),4)) if longds else None)
