import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { parseEnv } from 'node:util';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
const root='/var/folders/gc/73hvgtms3fdfdwh4ckhf61380000gn/T/ww-specimen-rule-pilot-w9ggf53i';
const protocol=JSON.parse(readFileSync(join(root,'protocol.json')));
const key=process.env.TRADIER_API_KEY || parseEnv(readFileSync('/Users/bollich/options-prototype/.env','utf8')).TRADIER_API_KEY;
if(!key) throw new Error('credential unavailable');
const rows=[];const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
for (const symbol of protocol.underlyings) {
 const dir=join(root,symbol.replace('/','_'));mkdirSync(dir);
 const urls=[
  ['quote','/markets/quotes?symbols='+encodeURIComponent(symbol)],
  ['history','/markets/history?symbol='+encodeURIComponent(symbol)+'&interval=daily&start=2026-07-01&end=2026-10-01'],
  ['expirations','/markets/options/expirations?symbol='+encodeURIComponent(symbol)+'&includeAllRoots=true'],
  ...protocol.expirations.map(e=>['chain-'+e,'/markets/options/chains?symbol='+encodeURIComponent(symbol)+'&expiration='+e+'&greeks=true'])
 ];
 for (const [kind,path] of urls) {
  const started=new Date().toISOString();let status=null,body='',error=null,headers={};
  try {
   const response=await fetch('https://api.tradier.com/v1'+path,{headers:{Authorization:'Bearer '+key,Accept:'application/json'},redirect:'error',signal:AbortSignal.timeout(25000)});
   status=response.status;body=await response.text();
   for(const h of ['date','content-type','x-ratelimit-allowed','x-ratelimit-used','x-ratelimit-available','x-ratelimit-expiry']) headers[h]=response.headers.get(h);
  } catch(e) {error=String(e);}
  const ended=new Date().toISOString();const artifact=symbol.replace('/','_')+'/'+kind+'.body';
  writeFileSync(join(root,artifact),body);
  rows.push({symbol,kind,path,status,error,started,ended,headers,raw_artifact:artifact,bytes:Buffer.byteLength(body),sha256:createHash('sha256').update(body).digest('hex')});
  await sleep(600);
 }
}
const m={schema:'ww-specimen-rule-pilot-capture/v0',protocol_sha256:createHash('sha256').update(readFileSync(join(root,'protocol.json'))).digest('hex'),rows};
writeFileSync(join(root,'manifest.json'),JSON.stringify(m,null,2)+'\n');
console.log(JSON.stringify({root,requests:rows.length,http200:rows.filter(r=>r.status===200).length,failures:rows.filter(r=>r.status!==200).map(r=>({symbol:r.symbol,kind:r.kind,status:r.status,error:r.error})),bytes:rows.reduce((s,r)=>s+r.bytes,0)}));
